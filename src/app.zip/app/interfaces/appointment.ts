export interface Appointment {
  id:number;
  user_id: number;
  admin_id: number;
  date: string;
  time: string;
}
