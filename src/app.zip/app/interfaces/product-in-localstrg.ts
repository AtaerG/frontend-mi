export interface ProductInLocalstrg {
  product: any,
  amount: number
}
