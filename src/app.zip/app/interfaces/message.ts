export interface Message {
  user_id:number,
  message:string
  name?:string
  created_at?: string
}
