import { OrderFindPipe } from './order-find.pipe';

describe('OrderFindPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderFindPipe();
    expect(pipe).toBeTruthy();
  });
});
