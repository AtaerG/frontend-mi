import { ProductFindPipe } from './product-find.pipe';

describe('ProductFindPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductFindPipe();
    expect(pipe).toBeTruthy();
  });
});
