import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-er-page',
  templateUrl: './er-page.component.html',
  styleUrls: ['./er-page.component.scss']
})
export class ErPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
